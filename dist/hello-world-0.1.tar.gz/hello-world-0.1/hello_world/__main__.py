from .hello_world import main

main()